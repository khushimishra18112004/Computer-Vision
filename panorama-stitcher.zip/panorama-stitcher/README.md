# Panorama Stitcher

Stitches two overlapping images into a single panorama using classical
(non-deep-learning) computer vision — the same pipeline behind phone
"Panorama" modes, implemented from scratch on top of OpenCV's primitives
so every step is visible and explainable.

## Pipeline

```
Image A ──┐
          ├─► ORB keypoints + descriptors
Image B ──┘
          │
          ▼
   Brute-force Hamming matching + Lowe's ratio test
          │
          ▼
   RANSAC-robust homography estimation (Direct Linear Transform)
          │
          ▼
   Perspective warp of Image A into Image B's plane
          │
          ▼
   Distance-transform feathered alpha blend across the seam
          │
          ▼
       Panorama
```

1. **Feature detection — ORB.** Each image is reduced to a sparse set of
   distinctive keypoints (corners, blobs, text edges) with a 256-bit binary
   descriptor per keypoint.
2. **Matching — Brute-Force Hamming + ratio test.** Every descriptor in
   image A is compared against every descriptor in image B. A match is kept
   only if the best candidate is meaningfully closer than the second-best
   (Lowe's ratio test), which filters out ambiguous matches before they can
   corrupt the geometry estimate.
3. **Homography estimation — RANSAC + DLT.** A homography is the 3×3
   projective transform that maps one camera's view of a planar-ish scene
   onto another's. Feature matches always contain outliers (repeated
   patterns, noise), so RANSAC repeatedly fits a homography from a random
   minimal sample of matches via the Direct Linear Transform and keeps the
   model with the most inliers — the matches consistent with a single
   geometric transform.
4. **Warping.** `cv2.warpPerspective` applies the estimated homography to
   remap image A's pixels into image B's coordinate frame, after computing
   a translation so both images land on a shared positive-coordinate
   canvas.
5. **Blending.** A hard cut at the seam is visible as a line in the output.
   Instead, a distance transform turns each image's binary footprint into a
   smooth per-pixel weight — pixels deep inside an image count fully, and
   pixels near its edge fade out — so the two images blend continuously
   across the overlap.

## Project structure

```
panorama-stitcher/
├── src/
│   ├── panorama.py          # detection, matching, RANSAC, warp, blend, CLI
│   └── generate_samples.py  # builds synthetic overlapping test images
├── tests/
│   └── test_panorama.py     # unit tests for each pipeline stage
├── samples/                 # generated sample input images
├── output/                  # generated panorama + match-visualization
├── requirements.txt
└── README.md
```

## Setup

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

Generate sample overlapping images (or supply your own two photos):

```bash
python src/generate_samples.py
```

Stitch them into a panorama:

```bash
python src/panorama.py samples/scene_left.jpg samples/scene_right.jpg \
    -o output/panorama.jpg --debug
```

`--debug` additionally writes `output/panorama_matches.jpg`, visualizing
exactly which keypoint matches RANSAC accepted as inliers — useful for
explaining/demoing the geometry step.

To stitch your own photos, use two images taken from the same spot,
rotating the camera slightly between shots, with at least ~30-40% overlap
between them:

```bash
python src/panorama.py my_photos/left.jpg my_photos/right.jpg -o output/my_panorama.jpg
```

## Tests

```bash
pip install pytest
python -m pytest tests/ -v
```

Tests cover: keypoint detection, descriptor matching correctness (an image
matched against itself should recover the identity transform), RANSAC's
minimum-match guard, the warp/blend canvas sizing, and a full
end-to-end run of the pipeline.

## Why this design (evaluation talking points)

- **Explicit pipeline instead of `cv2.Stitcher_create`** — every step
  (feature detection, matching, RANSAC, warp, blend) is implemented and
  inspectable rather than hidden behind a single black-box call, which is
  what a course evaluation on these topics is meant to probe.
- **RANSAC over plain least-squares** — feature matching between real
  images always contains false matches; a least-squares fit would let a
  handful of outliers distort the whole homography, while RANSAC is robust
  to a high proportion of outliers by design.
- **Feathered blending over a hard cut** — a naive overwrite at the seam
  produces a visible line even with a perfect homography, because exposure
  and warping introduce small pixel-value mismatches; distance-weighted
  blending removes that visible seam.
- **Synthetic sample generator** — makes the pipeline reproducible and
  testable without depending on external image downloads or datasets.

## Extending

- Support N > 2 images by chaining pairwise homographies back to a common
  reference frame.
- Swap ORB for SIFT (`cv2.SIFT_create`) for better matches on
  low-texture scenes, at higher compute cost.
- Add exposure compensation before blending for photos taken with
  different camera exposure settings.
