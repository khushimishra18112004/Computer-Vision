"""
Generates a synthetic 'scene' with plenty of distinct texture (so ORB has
real corners/features to find), then crops two overlapping, slightly
perspective-warped views out of it -- simulating two photos taken of the
same scene from adjacent camera positions.

Run:
    python src/generate_samples.py
Produces:
    samples/scene_left.jpg
    samples/scene_right.jpg
"""

import os
import numpy as np
import cv2


def build_scene(width=1400, height=800, seed=7):
    rng = np.random.default_rng(seed)
    scene = np.full((height, width, 3), 30, dtype=np.uint8)

    # Background gradient so distance-transform blending has something to show.
    for x in range(width):
        shade = int(30 + 60 * (x / width))
        scene[:, x] = (shade, shade // 2 + 20, shade // 3 + 40)

    # Scatter random shapes with varied colors, sizes, and outlines -- this
    # gives ORB many corners/blobs to detect, similar to a textured real scene.
    for _ in range(160):
        shape_type = rng.integers(0, 3)
        color = tuple(int(c) for c in rng.integers(40, 255, size=3))
        cx, cy = rng.integers(0, width), rng.integers(0, height)

        if shape_type == 0:
            r = int(rng.integers(8, 30))
            cv2.circle(scene, (cx, cy), r, color, -1)
            cv2.circle(scene, (cx, cy), r, (255, 255, 255), 1)
        elif shape_type == 1:
            w, h = int(rng.integers(15, 50)), int(rng.integers(15, 50))
            pt1 = (cx, cy)
            pt2 = (min(cx + w, width - 1), min(cy + h, height - 1))
            cv2.rectangle(scene, pt1, pt2, color, -1)
            cv2.rectangle(scene, pt1, pt2, (0, 0, 0), 1)
        else:
            pts = np.array(
                [[cx, cy], [cx + int(rng.integers(10, 40)), cy + int(rng.integers(-20, 20))],
                 [cx + int(rng.integers(-10, 30)), cy + int(rng.integers(10, 40))]],
                dtype=np.int32,
            )
            cv2.fillPoly(scene, [pts], color)

    # A few bold labels -- text corners are excellent ORB keypoints.
    for i, label in enumerate(["ALPHA", "BETA", "GAMMA", "DELTA", "EPSILON"]):
        x = 80 + i * (width // 5)
        cv2.putText(scene, label, (x, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (255, 255, 255), 2)

    return scene


def make_overlapping_views(scene, overlap_frac=0.45):
    height, width = scene.shape[:2]
    split = int(width * (1 - overlap_frac) / 1.0)

    left = scene[:, : int(width * 0.62)]
    right = scene[:, int(width * 0.38):]

    # Apply a mild random perspective warp to the right view so the two
    # images are not a trivial pure-translation pair (closer to real photos
    # taken from slightly different positions/angles).
    h, w = right.shape[:2]
    src = np.float32([[0, 0], [w, 0], [0, h], [w, h]])
    jitter = 18
    rng = np.random.default_rng(3)
    dst = src + rng.uniform(-jitter, jitter, size=src.shape).astype(np.float32)
    M = cv2.getPerspectiveTransform(src, dst)
    right_warped = cv2.warpPerspective(right, M, (w, h), borderValue=(30, 20, 40))

    return left, right_warped


def main():
    out_dir = os.path.join(os.path.dirname(__file__), "..", "samples")
    os.makedirs(out_dir, exist_ok=True)

    scene = build_scene()
    left, right = make_overlapping_views(scene)

    cv2.imwrite(os.path.join(out_dir, "scene_left.jpg"), left)
    cv2.imwrite(os.path.join(out_dir, "scene_right.jpg"), right)
    print(f"Saved sample views to {out_dir}/scene_left.jpg and scene_right.jpg")


if __name__ == "__main__":
    main()
