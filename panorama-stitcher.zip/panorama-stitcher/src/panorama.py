"""
Panorama Stitcher
==================
Stitches two (or more) overlapping images into a single panorama using
classical computer vision:

    1. Keypoint detection + local descriptors      (ORB)
    2. Descriptor matching                          (Brute-Force + Lowe's ratio test)
    3. Robust homography estimation                 (RANSAC + Direct Linear Transform)
    4. Perspective warping                          (cv2.warpPerspective)
    5. Seam blending                                (linear/feathered alpha blend)

Every step below is implemented explicitly (rather than calling
cv2.Stitcher_create) so the underlying math is visible and explainable.
"""

from __future__ import annotations

import argparse
import os
from dataclasses import dataclass

import cv2
import numpy as np


# --------------------------------------------------------------------------- #
# 1. Feature detection and description
# --------------------------------------------------------------------------- #
def detect_and_describe(image: np.ndarray, n_features: int = 4000):
    """Detect ORB keypoints and compute their binary descriptors."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    orb = cv2.ORB_create(nfeatures=n_features)
    keypoints, descriptors = orb.detectAndCompute(gray, None)
    return keypoints, descriptors


# --------------------------------------------------------------------------- #
# 2. Descriptor matching (Brute-Force Hamming + Lowe's ratio test)
# --------------------------------------------------------------------------- #
def match_descriptors(desc_a: np.ndarray, desc_b: np.ndarray, ratio: float = 0.75):
    """Match ORB descriptors with a ratio test to reject ambiguous matches."""
    bf = cv2.BFMatcher(cv2.NORM_HAMMING)
    raw_matches = bf.knnMatch(desc_a, desc_b, k=2)

    good_matches = []
    for pair in raw_matches:
        if len(pair) != 2:
            continue
        m, n = pair
        if m.distance < ratio * n.distance:
            good_matches.append(m)
    return good_matches


# --------------------------------------------------------------------------- #
# 3. Robust homography estimation (RANSAC over the matched point pairs)
# --------------------------------------------------------------------------- #
@dataclass
class HomographyResult:
    matrix: np.ndarray
    inlier_mask: np.ndarray
    src_pts: np.ndarray
    dst_pts: np.ndarray


def estimate_homography(
    kp_a, kp_b, matches, reproj_thresh: float = 4.0
) -> HomographyResult:
    """
    Estimate the homography H that maps points in image A onto image B,
    using RANSAC to discard outlier matches before the final Direct Linear
    Transform (DLT) solve that OpenCV performs internally.
    """
    if len(matches) < 4:
        raise ValueError(
            f"Need at least 4 matches to fit a homography, found {len(matches)}"
        )

    src_pts = np.float32([kp_a[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([kp_b[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

    matrix, mask = cv2.findHomography(
        src_pts, dst_pts, cv2.RANSAC, reproj_thresh
    )
    if matrix is None:
        raise RuntimeError("Homography estimation failed (RANSAC found no model).")

    return HomographyResult(matrix=matrix, inlier_mask=mask, src_pts=src_pts, dst_pts=dst_pts)


# --------------------------------------------------------------------------- #
# 4 + 5. Warp image A into image B's plane and feather-blend the overlap
# --------------------------------------------------------------------------- #
def warp_and_blend(image_a: np.ndarray, image_b: np.ndarray, H: np.ndarray) -> np.ndarray:
    """
    Warp image_a by H into a canvas that also contains image_b, then blend
    the overlapping region with a distance-weighted (feathered) alpha mask
    so the seam is not a hard edge.
    """
    h_a, w_a = image_a.shape[:2]
    h_b, w_b = image_b.shape[:2]

    # Corners of both images, used to size the output canvas correctly.
    corners_a = np.float32([[0, 0], [0, h_a], [w_a, h_a], [w_a, 0]]).reshape(-1, 1, 2)
    corners_b = np.float32([[0, 0], [0, h_b], [w_b, h_b], [w_b, 0]]).reshape(-1, 1, 2)
    warped_corners_a = cv2.perspectiveTransform(corners_a, H)

    all_corners = np.concatenate((warped_corners_a, corners_b), axis=0)
    x_min, y_min = np.floor(all_corners.min(axis=0).ravel()).astype(int)
    x_max, y_max = np.ceil(all_corners.max(axis=0).ravel()).astype(int)

    # Translation so everything lands inside positive canvas coordinates.
    translation = np.array([[1, 0, -x_min], [0, 1, -y_min], [0, 0, 1]], dtype=np.float64)
    canvas_size = (x_max - x_min, y_max - y_min)

    warped_a = cv2.warpPerspective(image_a, translation @ H, canvas_size)
    canvas_b = cv2.warpPerspective(image_b, translation, canvas_size)

    # Binary masks of where each warped image actually has content.
    mask_a = cv2.warpPerspective(
        np.ones((h_a, w_a), dtype=np.float32), translation @ H, canvas_size
    )
    mask_b = cv2.warpPerspective(
        np.ones((h_b, w_b), dtype=np.float32), translation, canvas_size
    )

    # Distance transform turns each mask into a feathering weight: pixels
    # deep inside an image get weight ~1, pixels near its border fade to 0,
    # so the seam blends smoothly instead of showing a hard cut.
    dist_a = cv2.distanceTransform((mask_a > 0).astype(np.uint8), cv2.DIST_L2, 5)
    dist_b = cv2.distanceTransform((mask_b > 0).astype(np.uint8), cv2.DIST_L2, 5)

    total = dist_a + dist_b
    total[total == 0] = 1  # avoid divide-by-zero where neither image has content
    weight_a = (dist_a / total)[..., None]
    weight_b = (dist_b / total)[..., None]

    blended = (
        warped_a.astype(np.float32) * weight_a + canvas_b.astype(np.float32) * weight_b
    )
    blended = np.clip(blended, 0, 255).astype(np.uint8)
    return blended


# --------------------------------------------------------------------------- #
# End-to-end pipeline
# --------------------------------------------------------------------------- #
def stitch(image_a: np.ndarray, image_b: np.ndarray, verbose: bool = True):
    """Stitch image_a and image_b, returning (panorama, debug_info)."""
    kp_a, desc_a = detect_and_describe(image_a)
    kp_b, desc_b = detect_and_describe(image_b)

    matches = match_descriptors(desc_a, desc_b)
    if verbose:
        print(f"[panorama] keypoints: A={len(kp_a)}  B={len(kp_b)}  good matches={len(matches)}")

    homography = estimate_homography(kp_a, kp_b, matches)
    n_inliers = int(homography.inlier_mask.sum())
    if verbose:
        print(f"[panorama] RANSAC inliers: {n_inliers}/{len(matches)}")

    panorama = warp_and_blend(image_a, image_b, homography.matrix)

    debug_info = {
        "keypoints_a": kp_a,
        "keypoints_b": kp_b,
        "matches": matches,
        "homography": homography,
    }
    return panorama, debug_info


def draw_match_debug(image_a, kp_a, image_b, kp_b, matches, inlier_mask, path: str):
    """Save a side-by-side visualization of inlier matches used for the homography."""
    mask_list = inlier_mask.ravel().tolist() if inlier_mask is not None else None
    vis = cv2.drawMatches(
        image_a, kp_a, image_b, kp_b, matches, None,
        matchColor=(0, 200, 0),
        singlePointColor=None,
        matchesMask=mask_list,
        flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS,
    )
    cv2.imwrite(path, vis)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main():
    parser = argparse.ArgumentParser(description="Stitch two overlapping images into a panorama.")
    parser.add_argument("image_a", help="Path to the left/first image")
    parser.add_argument("image_b", help="Path to the right/second image")
    parser.add_argument("-o", "--output", default="output/panorama.jpg", help="Output panorama path")
    parser.add_argument("--debug", action="store_true", help="Also save a match-visualization image")
    args = parser.parse_args()

    image_a = cv2.imread(args.image_a)
    image_b = cv2.imread(args.image_b)
    if image_a is None or image_b is None:
        raise FileNotFoundError("Could not read one or both input images.")

    panorama, debug_info = stitch(image_a, image_b)

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    cv2.imwrite(args.output, panorama)
    print(f"[panorama] Saved panorama to {args.output}")

    if args.debug:
        debug_path = os.path.splitext(args.output)[0] + "_matches.jpg"
        draw_match_debug(
            image_a, debug_info["keypoints_a"],
            image_b, debug_info["keypoints_b"],
            debug_info["matches"], debug_info["homography"].inlier_mask,
            debug_path,
        )
        print(f"[panorama] Saved match visualization to {debug_path}")


if __name__ == "__main__":
    main()
