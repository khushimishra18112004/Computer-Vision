"""
Unit tests for the panorama stitching pipeline.

Run with:
    python -m pytest tests/ -v
"""
import os
import sys

import cv2
import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from panorama import (  # noqa: E402
    detect_and_describe,
    match_descriptors,
    estimate_homography,
    warp_and_blend,
    stitch,
)


def make_textured_image(size=400, seed=0):
    """A synthetic image with enough corners/texture for ORB to key on."""
    rng = np.random.default_rng(seed)
    img = np.full((size, size, 3), 40, dtype=np.uint8)
    for _ in range(60):
        pt1 = tuple(rng.integers(0, size, size=2).tolist())
        pt2 = tuple(rng.integers(0, size, size=2).tolist())
        color = tuple(int(c) for c in rng.integers(50, 255, size=3))
        cv2.rectangle(img, pt1, pt2, color, -1)
    return img


@pytest.fixture(scope="module")
def textured_image():
    return make_textured_image()


def test_detect_and_describe_finds_keypoints(textured_image):
    keypoints, descriptors = detect_and_describe(textured_image)
    assert len(keypoints) > 0
    assert descriptors is not None
    assert descriptors.shape[0] == len(keypoints)


def test_match_descriptors_self_match_is_near_perfect(textured_image):
    """Matching an image's descriptors against themselves should yield a
    match for (almost) every keypoint, since every descriptor has an exact
    twin in the same set."""
    kp, desc = detect_and_describe(textured_image)
    matches = match_descriptors(desc, desc)
    assert len(matches) > 0
    # every match of an image against itself should have ~zero distance
    assert all(m.distance < 1e-3 for m in matches[:50])


def test_estimate_homography_identity_for_identical_images(textured_image):
    """Matching an image against itself should recover (close to) the
    identity homography."""
    kp, desc = detect_and_describe(textured_image)
    matches = match_descriptors(desc, desc)
    result = estimate_homography(kp, kp, matches)

    identity = np.eye(3)
    # Normalize scale (H is defined up to scale) before comparing.
    normalized = result.matrix / result.matrix[2, 2]
    assert np.allclose(normalized, identity, atol=0.5)


def test_estimate_homography_raises_on_too_few_matches():
    kp = [cv2.KeyPoint(0, 0, 1)] * 2
    with pytest.raises(ValueError):
        estimate_homography(kp, kp, [])


def test_warp_and_blend_output_shape_covers_both_images():
    img_a = make_textured_image(size=200, seed=1)
    img_b = make_textured_image(size=200, seed=2)
    H = np.eye(3, dtype=np.float64)
    H[0, 2] = 100  # shift image A 100px to the right relative to B

    blended = warp_and_blend(img_a, img_b, H)
    # Canvas must be big enough to contain the shifted image A plus image B.
    assert blended.shape[1] >= 200 + 100
    assert blended.shape[0] >= 200
    assert blended.dtype == np.uint8


def test_full_stitch_pipeline_runs_end_to_end():
    img_a = make_textured_image(size=300, seed=5)
    # Simulate a second, overlapping view by shifting a crop of the same image.
    img_b = np.roll(img_a, shift=40, axis=1)

    panorama, debug_info = stitch(img_a, img_b, verbose=False)
    assert panorama is not None
    assert panorama.size > 0
    assert len(debug_info["matches"]) > 0
